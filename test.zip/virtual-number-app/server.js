require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { MongoClient } = require("mongodb");
const twilio = require("twilio");

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Koneksi ke MongoDB
const client = new MongoClient(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

let db;

async function connectDB() {
  try {
    await client.connect();
    db = client.db("virtual_number"); // Nama database
    console.log("MongoDB Connected");
  } catch (error) {
    console.error("MongoDB connection error:", error);
  }
}

connectDB();

// Twilio Client
const twilioClient = new twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// **1. Endpoint menerima SMS dari Twilio**
app.post("/receive-sms", async (req, res) => {
  const { From, To, Body } = req.body;

  try {
    const smsCollection = db.collection("sms");
    await smsCollection.insertOne({
      from: From,
      to: To,
      body: Body,
      dateReceived: new Date(),
    });

    console.log("SMS Diterima:", req.body);
    res.send("<Response><Message>SMS diterima</Message></Response>");
  } catch (err) {
    console.error(err);
    res.status(500).send("Error menyimpan SMS");
  }
});

// **2. Endpoint mengambil semua SMS**
app.get("/messages", async (req, res) => {
  try {
    const smsCollection = db.collection("sms");
    const messages = await smsCollection.find().toArray();
    res.json(messages);
  } catch (err) {
    res.status(500).send("Error mengambil pesan");
  }
});

// **3. Endpoint mengirim SMS dengan Twilio**
app.post("/send-sms", async (req, res) => {
  const { to, message } = req.body;

  try {
    const sms = await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to,
    });

    console.log("SMS Terkirim:", sms.sid);
    res.json({ message: "SMS terkirim", sid: sms.sid });
  } catch (err) {
    console.error(err);
    res.status(500).send("Gagal mengirim SMS");
  }
});

// **4. Jalankan server**
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
